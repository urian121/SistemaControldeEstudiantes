

<?php $__env->startSection('content'); ?>


<div class="row justify-content-center">
    <div class="col-md-12 grid-margin stretch-card">
        <div class="card">
            <div class="card-body">
            <h2 class="text-center mb-3">
                DETALLES DEL ALUMNO<hr>
            </h2>

        <div class="row">
            <div class="col-md-12">
            <div class="card" style="width: 30rem;">
                <?php if( $alumno->foto_estudiante !=NULL ): ?>
                <img class="card-img-top" src="/fotosAlumnos/<?php echo e($alumno->foto_estudiante); ?>" alt="Foto-Alumno" class="imgs" style="width:200px; margin: 0 auto;">
                <?php else: ?>
                <img class="card-img-top" src="<?php echo e(asset('images/users.png')); ?>" alt="Foto-Alumno" class="imgs" style="width:200px; margin: 0 auto;">   
                <?php endif; ?>

                
                <div class="card-body">
                <h6 class="card-title"><strong>Nombre y Apellido:</strong>
                     <?php echo e($alumno->nameFullAlumno); ?> <hr>
                </h6>
                <h5 class="card-title"><strong>Edad:</strong> 
                    <?php echo e($alumno->edad_alumno); ?> 
                    <hr>
                </h5>
                <h5 class="card-title"><strong>Correo:</strong> 
                    <?php echo e($alumno->email_alumno); ?> 
                    <hr>
                </h5>
                <h5 class="card-title"><strong>Ciudad:</strong> 
                    <?php echo e($alumno->ciudad); ?> 
                    <hr>
                </h5>
                <h5 class="card-title"><strong>Teléfono:</strong> 
                    <?php echo e($alumno->phone_alumno); ?> 
                    <hr>
                </h5>
                
                <h5 class="card-title"><strong>Dirrección:</strong> 
                    <?php echo e($alumno->addres); ?> 
                    <hr>
                </h5>
                <h5 class="card-title"><strong>Curso:</strong> 
                    <?php echo e($alumno->curso_id); ?> 
                    <hr>
                </h5>
                <h5 class="card-title"><strong>Profesor:</strong> 
                    <?php echo e($alumno->profesor_id); ?> 
                    <hr>
                </h5>
               
                <a href="/alumno" class="btn btn-primary">
                    <i class="mdi mdi-undo-variant"></i> Volver
                </a>
                </div>
            </div>
            </div>
        </div>


            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SistemaControldeEstudiantes\resources\views/alumnos/view.blade.php ENDPATH**/ ?>