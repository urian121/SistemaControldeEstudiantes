

<?php $__env->startSection('content'); ?>
        

<div class="row justify-content-center">

    <?php if($update !=0): ?>
    <div class="col-md-10 grid-margin stretch-card">
        <div class="card">
            <div class="card-body">
            <h2 class="card-title text-center">ACTUALIZAR DATOS DEL PROFESOR <hr></h2>
            <form class="forms-sample" method="post" action="<?php echo e(route('profe.update', $profe->id)); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PATCH'); ?>
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="exampleInputUsername1">Nombre Y Apellido</label>
                        <input type="text" name="nameFull" class="form-control" value="<?php echo e($profe->nameFull); ?>" required>
                    </div>
                    <div class="col-md-6">
                        <label for="exampleInputUsername1">Cédula</label>
                        <input type="number" name="cedula" class="form-control" value="<?php echo e($profe->cedula); ?>" required>
                    </div>
                </div>

                <div class="row  mb-3">
                    <div class="col-md-6">
                        <label for="exampleInputUsername1">Teléfono</label>
                        <input type="number" name="phone" class="form-control" value="<?php echo e($profe->phone); ?>" required>
                    </div>
                    <div class="col-md-6">
                        <label for="exampleInputUsername1">Correo</label>
                        <input type="email" name="email" class="form-control" value="<?php echo e($profe->email); ?>" required>
                    </div>
                </div>

                <div class="row  mb-3">
                    <div class="col-md-6">
                        <label for="exampleInputUsername1">Profesión</label>
                        <input type="text" name="profesion" class="form-control" value="<?php echo e($profe->profesion); ?>">
                    </div>
                    <div class="col-md-6">
                        <label  for="exampleInputUsername1">Asignar Curso</label>
                        <select name="curso_id" class="form-control form-control-sm">
                            <option value="">Seleccione</option>
                            <?php $__currentLoopData = $cursos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $curso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($curso->id); ?>"> <?php echo e($curso->nombre_curso); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
    
                <div class="row  mb-5">
                    <div class="col-md-6">
                        <label for="exampleInputUsername1" style="text-align: center;">Foto actual</label>
                        <br>
                        <?php if($profe->foto_profesor !=NULL): ?>
                            <img src="/fotosProfes/<?php echo e($profe->foto_profesor); ?>" alt="foto profe" style="max-width: 100px; margin: 0 auto;">
                        <?php else: ?>
                            <img class="card-img-top" src="<?php echo e(asset('images/users.png')); ?>" alt="Foto-Profe" class="imgs" style="width:100px; margin: 0 auto;">
                        <?php endif; ?>
                        
                    </div>
                    <div class="col-md-6">
                        <label for="exampleInputUsername1">Cambiar Foto del Profesor</label>
                        <input type="file" name="foto_profesor" class="form-control">
                    </div>
                </div>
    
                
                <div class="form-group text-center">
                    <button type="submit" class="btn btn-primary mr-2">Actualizar Datos</button>
                    <a href="/"  class="btn btn-inverse-dark btn-fw">Cancelar</a>
                </div>
            </form>
            </div>
        </div>
    </div>
    
    <?php else: ?>
    <div class="col-md-4 grid-margin stretch-card">
    <div class="card">
        <div class="card-body">
        <h2 class="card-title text-center">REGISTRAR NUEVO PROFESOR <hr></h2>
        <form class="forms-sample" method="post" action="<?php echo e(route('profe.store')); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="exampleInputUsername1">Nombre Y Apellido</label>
                <input type="text" name="nameFull" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="exampleInputUsername1">Cédula</label>
                <input type="number" name="cedula" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="exampleInputUsername1">Teléfono</label>
                <input type="number" name="phone" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="exampleInputUsername1">Correo</label>
                <input type="email" name="email" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="exampleInputUsername1">Profesión</label>
                <input type="text" name="profesion" class="form-control">
            </div>
            <div class="form-group">
                <label class="col-sm-12 col-form-label">Asignar Curso</label>
                <select name="curso_id" class="form-control form-control-sm">
                    <option value="">Seleccione</option>
                    <?php $__currentLoopData = $cursos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $curso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($curso->id); ?>"> <?php echo e($curso->nombre_curso); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="form-group">
                <label for="exampleInputUsername1">Foto del Profesor</label>
                <input type="file" name="foto_profesor" class="form-control">
            </div>

            
            <div class="form-group text-center">
                <button type="submit" class="btn btn-primary mr-2">Registrar</button>
                <a href="/"  class="btn btn-inverse-dark btn-fw">Cancelar</a>
            </div>
        </form>
        </div>
    </div>
</div>


<?php if($profes->count()): ?>
<div class="col-md-8 grid-margin stretch-card">
<div class="card">
    <div class="card-body">
    <h4 class="card-title text-center">LISTA DE PROFESORES  <strong>( <?php echo e($profes->count()); ?> )</strong></h4>
    <div class="table-responsive">
        <table class="table table-hover">
        <thead>
            <tr>
            <th>Profesor</th>
            <th>Cédula</th>
            <th>Teléfono</th>
            <th>Acción</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $profes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($profe->nameFull); ?></td>
                <td><?php echo e($profe->cedula); ?></td>
                <td><?php echo e($profe->phone); ?></td>
                <td style="float: right">
                    <form action="<?php echo e(route('profe.destroy', $profe->id)); ?>" method="POST">
                        <a class="btn btn-inverse-primary" href="<?php echo e(route('profe.show',$profe->id)); ?>"  style="padding: 8px 15px !important;" title="Ver Detalles">
                            <i class="mdi mdi-account-card-details"></i> Ver
                        </a>
                        <a class="btn btn-inverse-success" href="<?php echo e(route('profe.edit',$profe->id)); ?>"  style="padding: 8px 5px !important;" title="Actualizar Registro">
                            <i class="mdi mdi-autorenew"></i>Actualizar
                        </a>
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-inverse-danger"  style="padding:  8px 5px !important;" title="Borrar Alumno">
                            <i class="mdi mdi-delete-sweep"></i>Borrar
                        </button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        </table>

            <br><br>
            <?php echo $profes->links(); ?>


        </div>
    </div>
</div>
</div>

<?php else: ?>
<p> No se ha creado ningún Profesor </p>
<?php endif; ?>  <!----->

<?php endif; ?> <!--FIN DEL UPDATE--->



</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SistemaControldeEstudiantes\resources\views/profes/addProfe.blade.php ENDPATH**/ ?>