

<?php $__env->startSection('content'); ?>
        
<?php if( session('mensaje') ): ?>
<div class="row re" id="proBanner">
    <div class="col-md-12 grid-margin">
      <div class="card bg-gradient-primary border-0">
        <div class="card-body py-3 px-4 d-flex align-items-center justify-content-between flex-wrap">
          <p class="mb-0 text-white font-weight-medium" style="margin: 0 auto;">
            <strong>Felicitaciones !</strong>
            <?php echo e(session('mensaje')); ?>

          </p>
          
          <div class="d-flex">
            <button id="bannerClose" class="btn border-0 p-0">
              <i class="mdi mdi-close text-white"></i>
            </button>
          </div>
        </div>
      </div>
    </div>
    </div>
<?php endif; ?>



<div class="row justify-content-center">
<?php if(($update !=0)): ?>

<div class="col-md-4 grid-margin stretch-card">
    <div class="card">
        <div class="card-body">
        <h2 class="card-title text-center">ACTUALIZAR DATOS DEL CURSO <hr></h2>
        <form class="forms-sample" method="post" action="<?php echo e(route('curso.update', $curso->id)); ?>">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PATCH'); ?>
            <div class="form-group">
                <label for="exampleInputUsername1">Nombre del Curso</label>
                <input type="text" name="nombre_curso" class="form-control" value="<?php echo e($curso->nombre_curso); ?>" required>
            </div>
            <div class="form-group">
                <label for="exampleInputUsername1">Valor del Curso</label>
                <input type="number" name="precio_curso" class="form-control" value="<?php echo e($curso->precio_curso); ?>" required>
            </div>
            <div class="form-group text-center">
                <button type="submit" class="btn btn-primary mr-2">Actualizar Curso</button>
                <a href="/"  class="btn btn-inverse-dark btn-fw">Cancelar</a>
            </div>

            <div class="form-group text-center">
                <a href="/curso/create" class="btn btn-primary">
                    <i class="mdi mdi-undo-variant"></i> Volver
                </a>
            </div>

        </form>
        </div>
    </div>
</div> 
<?php else: ?>
<div class="col-md-4 grid-margin stretch-card">
    <div class="card">
        <div class="card-body">
        <h2 class="card-title text-center">REGISTRAR NUEVO CURSO <hr></h2>
        <form class="forms-sample" method="post" action="<?php echo e(route('curso.store')); ?>">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="exampleInputUsername1">Nombre del Curso</label>
                <input type="text" name="nombre_curso" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="exampleInputUsername1">Valor del Curso</label>
                <input type="number" name="precio_curso" class="form-control" required>
            </div>
            <div class="form-group text-center">
                <button type="submit" class="btn btn-primary mr-2">Registrar</button>
                <a href="/"  class="btn btn-inverse-dark btn-fw">Cancelar</a>
            </div>
        </form>
        </div>
    </div>
</div> 


<?php if($cursosTable->count()): ?>
<div class="col-md-8 grid-margin stretch-card">
<div class="card">
    <div class="card-body">
    <h4 class="card-title text-center">LISTA DE CURSOS  <strong>( <?php echo e($cursosTotal->count()); ?> )</strong></h4>
    <div class="table-responsive">
        <table class="table table-hover">
        <thead>
            <tr>
            <th>Curso</th>
            <th>Valor</th>
            <th>Acción</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $cursosTable; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cur): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($cur->nombre_curso); ?></td>
                <td><?php echo e($cur->precio_curso); ?></td>
                <td style="float: right">
                    <form action="<?php echo e(route('curso.destroy',$cur->id)); ?>" method="POST">
                        <a class="btn btn-inverse-success" href="<?php echo e(route('curso.edit',$cur->id)); ?>"  style="padding: 8px 5px !important;" title="Actualizar Registro">
                            <i class="mdi mdi-autorenew"></i>Actualizar
                        </a>
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-inverse-danger"  style="padding:  8px 5px !important;" title="Borrar Alumno">
                            <i class="mdi mdi-delete-sweep"></i>Borrar
                        </button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        </table>

            <br><br>
            <?php echo $cursosTable->links(); ?>


        </div>
    </div>
</div>
</div>

<?php else: ?>
<p> No se ha creado ningún Curso </p>
<?php endif; ?>

<?php endif; ?> <!---fin del primer if else -->


</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SistemaControldeEstudiantes\resources\views/cursos/add.blade.php ENDPATH**/ ?>